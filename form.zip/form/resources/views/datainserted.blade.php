<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>datainserted</title>
</head>
<style>
    body {
        /* background-color: lightgrey; */
        /* width: 300px;
        height: 200px; */
        background: red;
        animation: mymove 8s infinite;
    }

    h1 {
        text-align: center;
        color:white;
    }

    table th {
        background-color: black;
        color: white;
    }

    table th:hover {
        background-color: grey;
        color: black;
    }

    table td {
        background-color: grey;
        color: white;
    }

    table td:hover {
        background-color: lightgrey;
        color: black;
    }

    .center {
        margin-left: auto;
        margin-right: auto;
    }

    table {
        width: 300px;
        height: 200px;
        background: red;
        animation: mymove 5s infinite;
    }

    @keyframes mymove {
        from {
            background-color: lightgrey;
        }

        to {
            background-color: blue;
        }
    }
</style>

<body>
    <div>
        <table class="center" border="5px">
            <h1>DATA INSERTED</h1>
            <tr>
                <th>S.no</th>
                <th>Name</th>
                <th>Email</th>
                <th>Age</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            @foreach($data as $abc)


            <tr>
                <td> {{ $abc->id }} </td>

                <td> {{ $abc->name }} </td>
                <td> {{ $abc->email }} </td>
                <td> {{ $abc->age }} </td>

                <td>
                    <a href="{{url('update')}}/{{ $abc->id}}">EDIT</a>
                </td>
                <td> <a href="{{url('delete')}}/{{ $abc->id}}">DELETE</a>
                </td>


            </tr>

            @endforeach
        </table>
    </div>
</body>

</html>