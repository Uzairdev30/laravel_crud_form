<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>datainserted</title>
</head>
<style>
    body {
        /* background-color: lightgrey; */
        /* width: 300px;
        height: 200px; */
        background: red;
        animation: mymove 8s infinite;
    }

    h1 {
        text-align: center;
        color:white;
    }

    table th {
        background-color: black;
        color: white;
    }

    table th:hover {
        background-color: grey;
        color: black;
    }

    table td {
        background-color: grey;
        color: white;
    }

    table td:hover {
        background-color: lightgrey;
        color: black;
    }

    .center {
        margin-left: auto;
        margin-right: auto;
    }

    table {
        width: 300px;
        height: 200px;
        background: red;
        animation: mymove 5s infinite;
    }

    @keyframes mymove {
        from {
            background-color: lightgrey;
        }

        to {
            background-color: blue;
        }
    }
</style>

<body>
    <div>
        <table class="center" border="5px">
            <h1>DATA INSERTED</h1>
            <tr>
                <th>S.no</th>
                <th>Name</th>
                <th>Email</th>
                <th>Age</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <tr>
                <td> <?php echo e($abc->id); ?> </td>

                <td> <?php echo e($abc->name); ?> </td>
                <td> <?php echo e($abc->email); ?> </td>
                <td> <?php echo e($abc->age); ?> </td>

                <td>
                    <a href="<?php echo e(url('update')); ?>/<?php echo e($abc->id); ?>">EDIT</a>
                </td>
                <td> <a href="<?php echo e(url('delete')); ?>/<?php echo e($abc->id); ?>">DELETE</a>
                </td>


            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\form\resources\views/datainserted.blade.php ENDPATH**/ ?>