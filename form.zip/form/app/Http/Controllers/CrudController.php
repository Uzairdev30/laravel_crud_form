<?php

namespace App\Http\Controllers;

use App\Models\crud;
use Illuminate\Http\Request;

class CrudController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $result['data'] = crud::all();
        return view('datainserted' ,$result);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
       
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $res = new crud;
        $res->name = $request->input("name");
        $res->email = $request->input("email");
        $res->age = $request->input("age");
        $res->save();
       return redirect("datainserted");
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(crud $crud)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(crud $crud , $id)
    {
        //
        $result['data'] = crud::find($id);
        return view('update' ,$result);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, crud $crud)
    {
        $res = new crud;
        $res->name = $request->input("name");
        $res->email = $request->input("email");
        $res->age = $request->input("age");
        $res->save();
       return redirect("datainserted");


        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $result['data'] = crud::find($id);
        if($result){
            $result['data']->delete();
        }
        return redirect("datainserted");
        //
    }
}
